@extends('grafik_menu_terlaris.master')
@section('content')
<body>
<div id="content_grafikmenuterlaris"></div>
</body>
@endsection
@push('page-scripts')
@endpush